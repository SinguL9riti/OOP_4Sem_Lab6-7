﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FurnitureShop.DAL.Interfaces;
using FurnitureShop.Domain;

namespace FurnitureShop.DAL.Repositories;

public class FurnitureTypeRepository(IDbContext dbContext) : IRepository<FurnitureType>
{
	private readonly IDbContext _dbContext = dbContext;
	public bool Create(FurnitureType entity)
	{
		_dbContext.FurnitureTypes.Add(entity);
		_dbContext.SaveChanges();
		return true;
	}

	public bool Delete(FurnitureType entity)
	{
		bool isRemoved = _dbContext.FurnitureTypes.Remove(entity);
		_dbContext.SaveChanges();
		return isRemoved;
	}

	public FurnitureType Read(int id)
	{
		return ReadAll().First(x => x.Id == id);
	}

	public IEnumerable<FurnitureType> ReadAll()
	{
		return _dbContext.FurnitureTypes;
	}

	public bool Update(FurnitureType oldEntity, FurnitureType newEntity)
	{
		_dbContext.SaveChanges();
		return true;
	}
}
