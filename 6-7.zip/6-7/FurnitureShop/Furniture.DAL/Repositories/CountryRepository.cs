﻿using FurnitureShop.DAL.Interfaces;
using FurnitureShop.Domain.Entities;

namespace FurnitureShop.DAL.Repositories;

public class CountryRepository(IDbContext dbContext) : IRepository<Country>
{
    private readonly IDbContext _dbContext = dbContext;
    public bool Create(Country entity)
    {
        _dbContext.Countries.Add(entity);
        _dbContext.SaveChanges();
        return true;
    }

    public bool Delete(Country entity)
    {
		bool isRemoved = _dbContext.Countries.Remove(entity);
		_dbContext.SaveChanges();
		return isRemoved;
	}

    public IEnumerable<Country> ReadAll()
    {
        return _dbContext.Countries;
    }

    public Country Read(int id)
    {
        return ReadAll().First(x => x.Id == id);
    }

    public bool Update(Country oldEntity, Country newEntity)
    {
		_dbContext.SaveChanges();
		return true;
	}
}
