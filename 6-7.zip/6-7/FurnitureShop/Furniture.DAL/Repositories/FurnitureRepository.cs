﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FurnitureShop.DAL.Interfaces;
using FurnitureShop.Domain;

namespace FurnitureShop.DAL.Repositories;

public class FurnitureRepository(IDbContext dbContext) : IRepository<Furniture>
{
	private readonly IDbContext _dbContext = dbContext;
	public bool Create(Furniture entity)
	{
		_dbContext.Furnitures.Add(entity);
		_dbContext.SaveChanges();
		return true;
	}

	public bool Delete(Furniture entity)
	{
		bool isRemoved = _dbContext.Furnitures.Remove(entity);
		_dbContext.SaveChanges();
		return isRemoved;
	}

	public Furniture Read(int id)
	{
		return ReadAll().First(x => x.Id == id);
	}

	public IEnumerable<Furniture> ReadAll()
	{
		return _dbContext.Furnitures;
	}

	public bool Update(Furniture oldEntity, Furniture newEntity)
	{
		Furniture furniture = _dbContext.Furnitures.Where(f => f.Name == oldEntity.Name).Single();
		furniture.Producer = newEntity.Producer;
		furniture.Dimensions = newEntity.Dimensions;
		furniture.Price = newEntity.Price;
		furniture.IsAvailable = newEntity.IsAvailable;
		furniture.Discount = newEntity.Discount;
		furniture.Type = newEntity.Type;
		_dbContext.SaveChanges();
		return true;
	}
}
