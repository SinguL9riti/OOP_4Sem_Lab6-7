﻿using Azure;
using FurnitureShop.DAL.Interfaces;
using FurnitureShop.Domain;
using FurnitureShop.Domain.Entities;
using Microsoft.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Data.SqlTypes;
using System.Reflection;

namespace FurnitureShop.DAL;

public class DbContext : IDbContext
{
    SqlConnection _connection;

    public List<Country> Countries { get; set; }
    public List<FurnitureType> FurnitureTypes { get; set; }
    public List<FurnitureDimensions> FurnitureDimensions { get; set; }
    public List<Producer> Producers { get; set; }
    public List<Furniture> Furnitures { get; set; }

    public DbContext()
    {
        string settings = ConfigurationManager.ConnectionStrings["DbFurnitureShop"].ConnectionString;
        _connection = new SqlConnection(settings);
        Countries = [];
        FurnitureTypes = [];
        FurnitureDimensions = [];
        Producers = [];
        Furnitures = [];
        SelectAll();
    }

	public List<Producer> SelectProducers()
	{
		try
		{
			_connection.Open();
			SqlCommand cmd = new()
			{
				Connection = _connection,
				CommandText = "SELECT * FROM Producers",
			};
			using (SqlDataReader reader = cmd.ExecuteReader())
			{
				while (reader.Read())
				{
                    Country? country = Countries.Find(x => x.Id == reader.GetInt32(2));
					ArgumentNullException.ThrowIfNull(country);
					Producer producer = new()
					{
						Id = reader.GetInt32(0),
						Name = reader.GetString(1),
                        Country = country
					};
					Producers.Add(producer);
				}
			}
			_connection.Close();
			return Producers;
		}
		catch (Exception ex)
		{
			throw new Exception("[Producers - Select]", ex);
		}
	}

	public List<Country> SelectCountries()
    {
        try
        {
            _connection.Open();
            SqlCommand cmd = new()
            {
                Connection = _connection,
                CommandText = "SELECT * FROM Countries",
            };
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    Country country = new()
                    {
                        Id = reader.GetInt32(0),
                        Name = reader.GetString(1)
                    };
                    Countries.Add(country);
                }
            }
			_connection.Close();
			return Countries;
        }
        catch (Exception ex)
        {
            throw new Exception("[Countries - Select]", ex);
        }
    }

	public List<FurnitureType> SelectFurnitureTypes()
	{
		try
		{
			_connection.Open();
			SqlCommand cmd = new()
			{
				Connection = _connection,
				CommandText = "SELECT * FROM FurnitureTypes",
			};
			using (SqlDataReader reader = cmd.ExecuteReader())
			{
				while (reader.Read())
				{
					FurnitureType type = new()
					{
						Id = reader.GetInt32(0),
						Name = reader.GetString(1)
					};
					FurnitureTypes.Add(type);
				}
			}
			_connection.Close();
			return FurnitureTypes;
		}
		catch (Exception ex)
		{
			throw new Exception("[FurnitureTypes - Select]", ex);
		}
	}

	public List<FurnitureDimensions> SelectFurnitureDimensions()
	{
		try
		{
			_connection.Open();
			SqlCommand cmd = new()
			{
				Connection = _connection,
				CommandText = "SELECT * FROM FurnitureDimensions",
			};
			using (SqlDataReader reader = cmd.ExecuteReader())
			{
				while (reader.Read())
				{
					FurnitureDimensions dimens = new()
					{
						Id = reader.GetInt32(0),
                        Length = (double) reader.GetDecimal(1),
                        Width = (double)reader.GetDecimal(2),
						Height = (double)reader.GetDecimal(3),
					};
					FurnitureDimensions.Add(dimens);
				}
			}
			_connection.Close();
			return FurnitureDimensions;
		}
		catch (Exception ex)
		{
			throw new Exception("[FurnitureDimensions - Select]", ex);
		}
	}

	public List<Furniture> SelectFurnitures()
	{
		try
		{
			_connection.Open();
			SqlCommand cmd = new()
			{
				Connection = _connection,
				CommandText = "SELECT * FROM Furnitures",
			};
			using (SqlDataReader reader = cmd.ExecuteReader())
			{
				while (reader.Read())
				{
					Producer? producer = Producers.Find(x => x.Id == reader.GetInt32(3));
					ArgumentNullException.ThrowIfNull(producer);

					FurnitureDimensions? dimensions = FurnitureDimensions.Find(x => x.Id == reader.GetInt32(2));
					ArgumentNullException.ThrowIfNull(dimensions);

					FurnitureType? type = FurnitureTypes.Find(x => x.Id == reader.GetInt32(1));
					ArgumentNullException.ThrowIfNull(type);

					Furniture furniture = new()
					{
						Id = reader.GetInt32(0),
						Producer = producer,
						Dimensions = dimensions,
						Type = type,
						Name = reader.GetString(4),
						Price = (double) reader.GetDecimal(5),
						Discount = reader.GetInt32(6),
						IsAvailable = reader.GetBoolean(7),
					};
					Furnitures.Add(furniture);
				}
			}
			_connection.Close();
			return Furnitures;
		}
		catch (Exception ex)
		{
			throw new Exception("[FurnitureDimensions - Select]", ex);
		}
	}

	private void SelectAll()
    {

        SelectCountries();
		SelectProducers();
		SelectFurnitureTypes();
		SelectFurnitureDimensions();
		SelectFurnitures();

    }

    

    private void InsertIntoFurnitures()
    {
        try
        {
            SqlCommand command = new()
            {
                Connection = _connection,
                CommandType = CommandType.Text,
                CommandText = "INSERT INTO Furnitures (FurnitureTypeId, FurnitureDimensionId, ProducerId, Name, Price, Discount, IsAvailable) " +
							  "VALUES (@FurnitureTypeId, @FurnitureDimensionId, @ProducerId, @Name, @Price, @Discount, @IsAvailable)"
			};

            command.Parameters.Add("@FurnitureTypeId", SqlDbType.Int, 4);
            command.Parameters.Add("@FurnitureDimensionId", SqlDbType.Int, 4);
            command.Parameters.Add("@ProducerId", SqlDbType.Int, 4);
            command.Parameters.Add("@Name", SqlDbType.VarChar, 100);
            command.Parameters.Add("@Discount", SqlDbType.Int, 4);
            command.Parameters.Add("@Price", SqlDbType.Money);
            command.Parameters.Add("@IsAvailable", SqlDbType.Bit);

            foreach (Furniture furniture in Furnitures)
            {
                command.Parameters["@FurnitureTypeId"].Value = furniture.Type.Id;
                command.Parameters["@FurnitureDimensionId"].Value = furniture.Dimensions.Id;
                command.Parameters["@ProducerId"].Value = furniture.Producer.Id;
                command.Parameters["@Name"].Value = furniture.Name;
                command.Parameters["@Discount"].Value = furniture.Discount;
                command.Parameters["@Price"].Value = furniture.Price;
                command.Parameters["@IsAvailable"].Value = furniture.IsAvailable;

                command.ExecuteNonQuery();
            }

        }
        catch (Exception ex)
        {
			throw new Exception(ex.Message);
        }
    }

    private void DeleteAll()
    {
        SqlCommand deleteFurnitures = new("DELETE FROM Furnitures", _connection);
		deleteFurnitures.ExecuteNonQuery();
    }

    private void UpdateAll()
    {
        DeleteAll();
		InsertIntoFurnitures();
	}

    public void SaveChanges()
    {
        _connection.Open();

        UpdateAll();

        _connection.Close();
    }

}