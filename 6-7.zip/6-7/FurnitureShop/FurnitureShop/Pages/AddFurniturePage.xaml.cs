﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using FurnitureShop.BLL.Interfaces;
using FurnitureShop.Domain;

namespace FurnitureShop.Pages;

public partial class AddFurniturePage : Page
{
	private readonly IProducerService _producerService;
	private readonly IFurnitureTypeService _furnitureTypeService;
	private readonly IFurnitureDimensionsService _furnitureDimensionsService;
	private readonly IFurnitureService _furnitureService;
	public AddFurniturePage(IFurnitureService furnitureService, IProducerService producerService,
							IFurnitureDimensionsService furnitureDimensionsService, IFurnitureTypeService furnitureTypeService)
	{
		_producerService = producerService;
		_furnitureDimensionsService = furnitureDimensionsService;
		_furnitureService = furnitureService;
		_furnitureTypeService = furnitureTypeService;
		InitializeComponent();
		comboBoxDimensions.ItemsSource = _furnitureDimensionsService.GetAll().Select(x => x.ToString());
		comboBoxProducer.ItemsSource = _producerService.GetAll().Select(x => x.Name);
		comboBoxType.ItemsSource = _furnitureTypeService.GetAll().Select(x => x.Name);
	}

	private void SaveButton_Click(object sender, RoutedEventArgs e)
	{
		if (comboBoxDimensions.SelectedItem == null)
		{
			MessageBox.Show("Не выбраны габариты мебели");
			return;
		}

		if (comboBoxProducer.SelectedItem == null)
		{
			MessageBox.Show("Не выбран производитель мебели");
			return;
		}

		if (comboBoxType.SelectedItem == null)
		{
			MessageBox.Show("Не выбран тип мебели");
			return;
		}

		if (txtName.Text.Length <= 0)
		{
			MessageBox.Show("Не введено название мебели");
			return;
		}

		if (double.TryParse(txtPrice.Text.Replace(',', '.'), CultureInfo.InvariantCulture, out double price) &&
			int.TryParse(txtDiscount.Text, CultureInfo.InvariantCulture, out int discount))
		{
			Furniture furniture = new()
			{
				Price = price,
				Discount = discount,
				Name = txtName.Text,
				IsAvailable = txtIsAvailable.IsChecked!.Value,
				Producer = _producerService.GetAllModels().First(x => x.Name == comboBoxProducer.SelectedItem.ToString()),
				Dimensions = _furnitureDimensionsService.GetAll().First(x => x.ToString() == comboBoxDimensions.SelectedItem.ToString()),
				Type = _furnitureTypeService.GetAll().First(x => x.Name == comboBoxType.SelectedItem.ToString()),
			};

			_furnitureService.Add(furniture);
			MessageBox.Show("Мебель успешно добавлена!");
		}
		else
		{
			MessageBox.Show("Не верный формат ввода цены или скидки");
		}

	}
}