﻿using FurnitureShop.BLL.Implementations;
using FurnitureShop.BLL.Interfaces;
using FurnitureShop.DAL;
using FurnitureShop.DAL.Interfaces;
using FurnitureShop.DAL.Repositories;
using FurnitureShop.Domain;
using FurnitureShop.Domain.Entities;
using FurnitureShop.Pages;
using FurnitureShop.View;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FurnitureShop;

public partial class MainWindow : Window
{
    private readonly ICountryService _countryService;
    private readonly IProducerService _producerService;
    private readonly IFurnitureTypeService _furnitureTypeService;
    private readonly IFurnitureDimensionsService _furnitureDimensionsService;
    private readonly IFurnitureService _furnitureService;

	public MainWindow()
    {
        InitializeComponent();

        IDbContext dbContext = new DbContext();

        IRepository<Country> countryRepository = new CountryRepository(dbContext);
        _countryService = new CountryService(countryRepository);

		IRepository<Producer> producerRepository = new ProducerRepository(dbContext);
		_producerService = new ProducerService(producerRepository);

		IRepository<FurnitureType> furnitureTypeRepository = new FurnitureTypeRepository(dbContext);
		_furnitureTypeService = new FurnitureTypeService(furnitureTypeRepository);

		IRepository<FurnitureDimensions> furnitureDimensionsRepository = new FurnitureDimensionsRepository(dbContext);
		_furnitureDimensionsService = new FurnitureDimensionsService(furnitureDimensionsRepository);

		IRepository<Furniture> furnitureRepository = new FurnitureRepository(dbContext);
		_furnitureService = new FurnitureService(furnitureRepository);

	}

	private void FurnitureButton_Click(object sender, RoutedEventArgs e)
	{
		viewFrame.Content = new FurnitureView(_furnitureService);
	}

	private void ProducerButton_Click(object sender, RoutedEventArgs e)
	{
		viewFrame.Content = new ProducerView(_producerService);
	}

	private void AddButton_Click(object sender, RoutedEventArgs e)
	{
		viewFrame.Content = new AddFurniturePage(_furnitureService, _producerService, _furnitureDimensionsService, _furnitureTypeService);
	}

	private void RemoveButton_Click(object sender, RoutedEventArgs e)
	{
		viewFrame.Content = new RemoveFurniturePage(_furnitureService);
	}

	private void UpdateButton_Click(object sender, RoutedEventArgs e)
	{
		viewFrame.Content = new UpdateFurniturePage(_furnitureService, _producerService, _furnitureDimensionsService, _furnitureTypeService);
	}
}