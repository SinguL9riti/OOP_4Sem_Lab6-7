﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FurnitureShop.BLL.Interfaces;
using FurnitureShop.DAL.Interfaces;
using FurnitureShop.DAL.Repositories;
using FurnitureShop.Domain;
using FurnitureShop.Domain.ViewModels;

namespace FurnitureShop.BLL.Implementations;

public class FurnitureService(IRepository<Furniture> furnitureRepository) : IFurnitureService
{
	private readonly IRepository<Furniture> _furnitureRepository = furnitureRepository;

	public void Add(Furniture furniture)
	{
		_furnitureRepository.Create(furniture);
	}

	public IEnumerable<FurnitureViewModel> GetAll()
	{
		List<FurnitureViewModel> list = [];
		foreach (Furniture furniture in _furnitureRepository.ReadAll())
		{
			list.Add(new(furniture));
		}
		return list;
	}

	public void Remove(Furniture furniture)
	{
		Furniture furnitureToDelete = _furnitureRepository.ReadAll().First(x => x.Name == furniture.Name);
		_furnitureRepository.Delete(furnitureToDelete);
	}

	public void Update(Furniture oldFurniture, Furniture newFurniture)
	{
		_furnitureRepository.Update(oldFurniture, newFurniture);
	}
}
