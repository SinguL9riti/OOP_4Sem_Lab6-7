﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FurnitureShop.Domain;
using FurnitureShop.Domain.ViewModels;

namespace FurnitureShop.BLL.Interfaces;

public interface IFurnitureService
{
	public IEnumerable<FurnitureViewModel> GetAll();
	public void Add(Furniture furniture);
	public void Remove(Furniture furniture);
	public void Update(Furniture oldFurniture, Furniture newFurniture);
}
