﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FurnitureShop.Domain;
using FurnitureShop.Domain.ViewModels;

namespace FurnitureShop.BLL.Interfaces;

public interface IProducerService
{
	public IEnumerable<ProducerViewModel> GetAll();
	public IEnumerable<Producer> GetAllModels();
}
