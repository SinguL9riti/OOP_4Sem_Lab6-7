﻿using FurnitureShop.Domain.Entities;

namespace FurnitureShop.Domain;

public class Furniture(int id, string name, double price, int discount, bool isAvailable, Producer producer, FurnitureType type, FurnitureDimensions dimensions)
{
    public int Id { get; set; } = id;
    public string Name { get; set; } = name;
    public double Price { get; set; } = price;
    public int Discount { get; set; } = discount;
    public bool IsAvailable { get; set; } = isAvailable;
    public Producer Producer { get; set; } = producer;
    public FurnitureType Type { get; set; } = type;
    public FurnitureDimensions Dimensions { get; set; } = dimensions;

    public Furniture() : this(0, "", 0, 0, false, new(), new(), new())
    {
        
    }
}
