﻿using FurnitureShop.Domain.Entities;

namespace FurnitureShop.Domain;

public class Producer(int id, string name, Country country)
{
    public int Id { get; set; } = id;
    public string Name { get; set; } = name;
    public Country Country { get; set; } = country;

    public Producer(): this(0, "", new())
    {
        
    }
}
