﻿using FurnitureShop.Domain.Entities;

namespace FurnitureShop.Domain;

public class FurnitureType(int id, string name)
{
    public int Id { get; set; } = id;
    public string Name { get; set; } = name;

    public FurnitureType() : this(0, "")
    {
        
    }
}
