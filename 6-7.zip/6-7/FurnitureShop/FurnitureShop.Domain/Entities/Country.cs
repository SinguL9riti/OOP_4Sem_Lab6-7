﻿namespace FurnitureShop.Domain.Entities;

public class Country(int id, string name)
{
    public int Id { get; set; } = id;
    public string Name { get; set; } = name;

    public Country() : this(0, "") {  }
}
