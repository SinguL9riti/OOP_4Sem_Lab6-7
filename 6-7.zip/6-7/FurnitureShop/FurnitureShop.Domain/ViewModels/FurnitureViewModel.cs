﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace FurnitureShop.Domain.ViewModels;

public class FurnitureViewModel(Furniture furniture)
{
	public int Id { get; set; } = furniture.Id;
	public string Name { get; set; } = furniture.Name;
	public string Price { get; set; } = furniture.Price.ToString("F2");
	public int Discount { get; set; } = furniture.Discount;
	public bool IsAvailable { get; set; } = furniture.IsAvailable;
	public string Producer { get; set; } = furniture.Producer.Name;
	public string Type { get; set; } = furniture.Type.Name;
	public string Dimensions { get; set; } = $"{furniture.Dimensions.Length}, {furniture.Dimensions.Width}, {furniture.Dimensions.Height}";
}
